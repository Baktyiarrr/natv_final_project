package kg.mega.natv_final_project.models.enums;

public enum Status {
    CREATED,NOT_CREATED
}
