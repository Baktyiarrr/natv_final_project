package kg.mega.natv_final_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NatvFinalProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(NatvFinalProjectApplication.class, args);
    }

}
