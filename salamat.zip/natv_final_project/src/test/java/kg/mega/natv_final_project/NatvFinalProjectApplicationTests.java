package kg.mega.natv_final_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NatvFinalProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
