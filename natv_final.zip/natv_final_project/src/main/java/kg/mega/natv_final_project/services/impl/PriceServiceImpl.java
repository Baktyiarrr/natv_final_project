package kg.mega.natv_final_project.services.impl;

import kg.mega.natv_final_project.services.PriceService;
import org.springframework.stereotype.Service;

@Service
public class PriceServiceImpl implements PriceService {
}
