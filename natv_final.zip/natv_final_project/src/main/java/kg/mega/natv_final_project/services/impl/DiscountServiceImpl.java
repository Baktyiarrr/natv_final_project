package kg.mega.natv_final_project.services.impl;

import kg.mega.natv_final_project.services.DiscountService;
import org.springframework.stereotype.Service;

@Service
public class DiscountServiceImpl implements DiscountService {
}
