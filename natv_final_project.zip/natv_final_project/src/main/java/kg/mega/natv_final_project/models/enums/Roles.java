package kg.mega.natv_final_project.models.enums;

public enum Roles {
    ADMIN,
    USER,
    MODERATOR
}
