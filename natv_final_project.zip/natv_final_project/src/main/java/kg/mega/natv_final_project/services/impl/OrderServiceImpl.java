package kg.mega.natv_final_project.services.impl;

import kg.mega.natv_final_project.mappers.OrderMapper;
import kg.mega.natv_final_project.models.dto.requests.OrderDto;
import kg.mega.natv_final_project.models.entities.Order;
import kg.mega.natv_final_project.repositories.OrderRepo;
import kg.mega.natv_final_project.services.OrderService;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl implements OrderService {
    private final OrderRepo orderRepo;
    private final OrderMapper orderMapper;

    public OrderServiceImpl(OrderRepo orderRepo, OrderMapper orderMapper) {
        this.orderRepo = orderRepo;
        this.orderMapper = orderMapper;
    }

    @Override
    public OrderDto save(OrderDto orderDto) {
        Order order = orderMapper.orderDtoToOrder(orderDto);
        order = orderRepo.save(order);
        return orderDto;
    }
}
