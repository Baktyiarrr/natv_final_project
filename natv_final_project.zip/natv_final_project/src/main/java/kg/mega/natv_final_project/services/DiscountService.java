package kg.mega.natv_final_project.services;

public interface DiscountService {
}
